#include <iostream>
#include "TAD_abin_din.hpp"
#include <iostream>
#include <fstream>
#include "abin_E-S.h"

using namespace std;

typedef char tElto;
const tElto fin = '#'; 

template <typename T>
double ratioNostalgicos(const Abin<T>& A);

template <typename T>
int numeroNodos(typename Abin<T>::nodo, const Abin<T>& A);

template <typename T>
int numeroNostalgicos(typename Abin<T>::nodo,const Abin<T>& A);

template <typename T>
bool nodoNostalgico(typename Abin<T>::nodo, const Abin<T>& A);

int main()
{
Abin<tElto> A;
ifstream fe("abin.dat"); // abrir fichero de entrada
rellenarAbin(fe, A); // desde fichero

cout << "El arbol tiene un ratio de "ratioNostalgicos(A) << " perfe." endl;
}



template <typename T>
double ratioNostalgicos(const Abin<T>& A)
{
	return ((double)numeroNostalgicos(A.raizB(), A)/numeroNodos(A.raizB(), A));
}


template <typename T>
int numeroNodos(typename Abin<T>::nodo n,const Abin<T>& A)
{
	if (n == Abin<T>::NODO_NULO)
	{
		return 0;
	}
	else
	{
		return (1+ numeroNodos(A.hijoDrchoB(n), A) + numeroNodos(A.hijoIzqdoB(n), A));
	}
}

template <typename T>
int numeroNostalgicos(typename Abin<T>::nodo n,const Abin<T>& A)
{
	if (n == Abin<T>::NODO_NULO)
	{
		return 0;
	}
	else
	{
		if (nodoNostalgico(n,A)) return (1+numeroNostalgicos(A.hijoDrchoB(n), A) + numeroNostalgicos(A.hijoIzqdoB(n), A));
		else return (numeroNostalgicos(A.hijoDrchoB(n), A) + numeroNostalgicos(A.hijoIzqdoB(n), A));
	}
}

template <typename T>
bool nodoNostalgico(typename Abin<T>::nodo n,const Abin<T>& A)
{
	if (cuantosArriba(n,A) > numeroNodos(n,A)) return true;
	else return false;
}

template <typename T>
int cuantosArriba(typename Abin<T>::nodo n,const Abin<T>& A)
{
	if (n == A.raizB())
	{
		return 1;
	}
	else
	{
		return (1 + cuantosArriba(A.padreB(n), A));
	}
}
