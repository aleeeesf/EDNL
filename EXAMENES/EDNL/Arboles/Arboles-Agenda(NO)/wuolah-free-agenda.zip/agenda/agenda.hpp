/*Haz una agenda usando un Arbol de búsqueda. Utiliza como estructura una
con los campos telefono y nombre por ejemplo y acuerdate de sobrecargar
los operandos de comparación de la estructura.*/
